<?php

namespace Developpement\Checkoutinformation\Controller;

use Hp\Faq\Entity\Faq;
use Hp\Faq\Entity\FaqLang;
use Hp\Faq\Form\FaqType;
use Language;
use PrestaShop\PrestaShop\Adapter\Entity\Country;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use PrestaShopBundle\Entity\Lang;
use Symfony\Component\HttpFoundation\Request;

class CheckInfoController extends FrameworkBundleAdminController
{
    public function indexAction(Request $request)
    {
        $languages = \Language::getLanguages(true);

        $formBuilder = $this->get('check.form.identifiable_object.builder');
        $form = $formBuilder->getForm();
        
        $form->handleRequest($request); 
        if ($form->isSubmitted() && $form->isValid()) {
            $information = $form->get('information')->getData();
            foreach ($languages as $lang) {
                $langId = $lang['id_lang'];
                $langIsoCode = \Tools::strtoupper($lang['iso_code']);
                $info = $information[$langId];
                \Configuration::updateValue('CHECKOUT_INFORMATION_'.$langIsoCode, $info);
            }
            $this->addFlash('success', $this->trans('Information created', 'Modules.CheckInfo.Admin'));
            return $this->redirectToRoute('mm_check_index');
        }

        return $this->render('@Modules/checkoutinformation/views/templates/admin/index.html.twig', [
            'enableSidebar' => true,
            'layoutTitle' => $this->trans('Information', 'Modules.CheckInfo.Admin'),
            'form' => $form->createView(),
        ]);
    }
}