<?php
namespace Developpement\Checkoutinformation\Form;

use PrestaShopBundle\Form\Admin\Type\TranslatableType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use PrestaShopBundle\Form\Admin\Type\FormattedTextareaType;

use Symfony\Component\Form\FormBuilderInterface as FormFormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class CheckType extends AbstractType
{
    public function buildForm(FormFormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('information', TranslatableType::class, [
                'label'    => '',
                'required' => true,
                'type'     => FormattedTextareaType::class,
                'attr'     => [
                    'placeholder' => "here is the Information",
                    'class'       => 'form-control',
                ],
            ]);

    }
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => null,
        ]);
    }
}