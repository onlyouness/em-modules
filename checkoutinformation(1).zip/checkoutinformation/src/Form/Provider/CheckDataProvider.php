<?php

declare (strict_types = 1);

namespace Developpement\Checkoutinformation\Form\Provider;

use Hp\Faq\Entity\Faq;
use PrestaShop\PrestaShop\Core\Form\IdentifiableObject\DataProvider\FormDataProviderInterface;

class CheckDataProvider implements FormDataProviderInterface
{

    public function getData($id){
        $data = [
            'information' => \Configuration::get('CHECKOUT_INFORMATION'),
        ];
        return $data;
    }
    /**

     * Get default form data for creating a new FAQ.

     * This is used when the form is displayed for creating a new FAQ.

     *

     * @return array

     */

    public function getDefaultData()
    {
        $fr = \Configuration::get('CHECKOUT_INFORMATION_FR');
        $en = \Configuration::get('CHECKOUT_INFORMATION_EN');
        return [
            
            'information' => [1 => $fr, 2 => $en],
        ];
    }


}