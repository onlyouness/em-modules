var resItem = document.querySelectorAll('.res_item');

resItem.forEach((item)=>{
    item.addEventListener('mouseover',(event)=>{

    })
} )