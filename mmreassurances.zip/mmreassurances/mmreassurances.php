<?php
declare (strict_types = 1);

use Hp\Mmreassurances\Entity\Reassurance;

class MmReassurances extends Module
{
    public function __construct()
    {
        $this->name          = 'mmreassurances';
        $this->tab           = 'administration';
        $this->version       = '1.0.0';
        $this->author        = 'Youness Elbaz MM';
        $this->need_instance = 0;
        $this->bootstrap     = true;

        parent::__construct();

        $this->displayName = $this->l('MM Labels Reassurances');
        $this->description = $this->l('Allows user to add a dynamic Labels.');

        $this->ps_versions_compliancy = ['min' => '1.7', 'max' => _PS_VERSION_];
    }
    public function install()
    {
        return (
            parent::install() && $this->installQueries() && $this->registerHook('displayHome')
        );
    }
    public function uninstall()
    {
        return $this->unInstallQueries() && parent::uninstall();
    }

    public function installQueries()
    {
        $queries   = [];
        $queries[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'reassurance` (
        `id` int NOT NULL AUTO_INCREMENT,
        `image` varchar(250) NOT NULL,
        `position` int NOT NULL DEFAULT -1,
        `active` int NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`)
        )ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET= utf8';
        $queries[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'reassurance_lang` (
        `id_reassurance` int NOT NULL,
        `title` varchar(255) NOT NULL,
        `description` LONGTEXT NOT NULL,
        PRIMARY KEY (`id_reassurance`)
        )ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET= utf8';
        foreach ($queries as $query) {
            if (! Db::getInstance()->execute($query)) {
                return false;
            }
        }
        return true;
    }

    public function unInstallQueries()
    {
        $queries   = [];
        $queries[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'reassurance` ';
        $queries[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'reassurance_lang` ';
        foreach ($queries as $query) {
            if (! Db::getInstance()->execute($query)) {
                return false;
            }
        }
        return true;
    }

    public function hookDisplayHome()
    {
        $em           = $this->get('doctrine.orm.entity_manager');
        $langId       = (int) $this->context->language->id;
        $reassurances = $em->getRepository(Reassurance::class)->findReassuranceByLangAndActive($langId);

        $this->context->smarty->assign(['reassurances' => (array) $reassurances]);
        return $this->display(__FILE__, 'views/templates/hook/home.tpl');
    }
    public function hookDisplayHeader()
    {
        $this->context->controller->addJS("{$this->_path}/views/js/admin.js");
        $this->context->controller->addCSS("{$this->_path}/views/css/admin.css");
    }
}
