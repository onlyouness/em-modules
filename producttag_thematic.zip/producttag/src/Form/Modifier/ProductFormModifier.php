<?php

declare (strict_types = 1);

namespace Hp\Producttag\Form\Modifier;

use PrestaShopBundle\Form\FormBuilderModifier;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;

final class ProductFormModifier
{
    /**
     * @var FormBuilderModifier
     */
    private $formBuilderModifier;

    /**
     * @param FormBuilderModifier $formBuilderModifier
     */
    public function __construct(
        FormBuilderModifier $formBuilderModifier
    ) {
        $this->formBuilderModifier = $formBuilderModifier;
    }

    /**
     * @param int|null $productId
     * @param FormBuilderInterface $productFormBuilder
     */
    public function modify(
        int $productId,
        FormBuilderInterface $productFormBuilder
    ): void {
        $db    = \Db::getInstance();
        $query = new \DbQuery();
        $query->select('id, title')
            ->from('thematic')
            ->where('active = 1');
        $thematics = $db->executeS($query);
    
        $choices = [];
        foreach ($thematics as $thematic) {
            if (isset($thematic['title'], $thematic['id'])) {
                $choices[$thematic['title']] = $thematic['id'];
            }
        }
    
        $descriptionFormBuilder = $productFormBuilder->get('description');
        $this->formBuilderModifier->addAfter(
            $descriptionFormBuilder,
            'description',
            'thematic_custom',
            ChoiceType::class,
            [
                'label'        => 'Thematic',
                'label_attr'   => [
                    'title' => 'Thematic',
                    'class' => 'text-info',
                ],
                'attr'         => [
                    'placeholder' => 'Select a thematic',
                ],
                'choices'      => $choices,
                'choice_label' => function ($choice, $key, $value) {
                    return $key; 
                },
                'choice_value' => function ($choice) {
                    return (string) $choice;
                },
                'data'         => $productId ? $this->getThematic($productId) : null,
                'empty_data'   => '',
                'form_theme'   => '@PrestaShop/Admin/TwigTemplateForm/prestashop_ui_kit_base.html.twig',
            ]
        );
    }
    public function getThematic($productId)
    {
        $db    = \Db::getInstance();
        $query = new \DbQuery();
        $query->select('id_tag')
            ->from('product_thematic')
            ->where('id_product = ' . (int) $productId);
        $thematic = $db->getValue($query);
    
        return $thematic;
    }
    
}
