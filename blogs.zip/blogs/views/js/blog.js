$(document).ready(function () {
    window.prestashop.component.initComponents(["TinyMCEEditor"]);
});
