const {$} = window;
$(() => {
window.prestashop.component.initComponents(['TranslatableInput', ])
})