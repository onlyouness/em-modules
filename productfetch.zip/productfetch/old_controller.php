<?php

class ProductFetchFetchModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {

        $logFilePath = __DIR__ . '/logs/operations-' . date('Y-m-d') . '.log';

        $fetchedProducts = $this->fetchProductsAll();
        $limitedProducts = array_slice($fetchedProducts, 0, 5);

        $this->logMessage("after getting the products all", $logFilePath);

        $productDetails = $this->fetchProductsItems($limitedProducts);

        $insertedCount = 0;
        $totalProducts = count($productDetails)/2;

        $this->logMessage("Starting inserting products into the DB.", $logFilePath);

        // Initialize the counter for successfully inserted products
        foreach ($productDetails as $index => $product) {
            $this->logMessage("Processing Product with index " . $index, $logFilePath);

            // Check if product already exists
            $request = 'SELECT `id_product` FROM `' . _DB_PREFIX_ . 'product` p WHERE p.reference = ' . (int) $product['PartNumber'];
            $exists = Db::getInstance()->getValue($request);

            if (!$exists) {
                try {
                    // Prepare product data for French (ID 1)
                    $productName = ['1' => $product['PartName']];
                    $description = ['1' => $product['Description']];
                    $link_rewrite = ['1' => $this->slugUrl($product['PartName'])];
                    $getCategoryID = 1; // Assign to default category or retrieved dynamically

                    // Create a new Product object
                    $productObj = new Product();
                    $productObj->name = $productName;
                    $productObj->ean13 = ''; // Optional, can be updated if needed
                    $productObj->reference = $product['PartNumber'];
                    $productObj->id_category_default = $getCategoryID;
                    $productObj->indexed = 1;
                    $productObj->description = $description;
                    $productObj->condition = 'new';
                    $productObj->redirect_type = '404';
                    $productObj->visibility = 'both';
                    $productObj->id_supplier = 1; // Update with your supplier ID
                    $productObj->link_rewrite = $link_rewrite;
                    $productObj->quantity = (int) $product['Quantity'];
                    $productObj->price = (float) $product['Price'];
                    $productObj->active = 1;

                    // Add the product to the database
                    if ($productObj->add()) {
                        $productObj->addToCategories([$getCategoryID]);
                        $this->logMessage("Product inserted successfully with ID " . $productObj->id, $logFilePath);
                        $insertedCount++;
                    } else {
                        $this->logMessage("Error inserting product: " . $product['PartNumber'], $logFilePath);
                    }
                } catch (Exception $e) {
                    $this->logMessage("Error while processing product: " . $e->getMessage(), $logFilePath);
                }
            } else {
                $this->logMessage("Product already exists with ID " . $exists, $logFilePath);
            }
        }

        // After the loop, log the count of successfully inserted products
        $this->logMessage("Total products processed: " . $totalProducts, $logFilePath);
        $this->logMessage("Total products successfully inserted: " . $insertedCount, $logFilePath);

        // Tools::dieObject(['productDetails' => $productDetails]);

        $this->context->smarty->assign([
            'totalProducts' => $totalProducts,
            'insertedCount' => $insertedCount,
        ]);
        $this->setTemplate('module:productfetch/views/templates/front/fetch.tpl');
    }





    public function fetchProductsAll()
    {
        $logFilePath = __DIR__ . '/logs/operations-' . date('Y-m-d') . '.log';
        $this->logMessage("Starting fetchProductsAll operation.", $logFilePath);

        $soapUrl = "https://dedal.polcar.com/Dystrybutorzy/Products.asmx";
        $soapUser = "eurlaf";
        $soapPassword = "ujdM676fj9sSrJt";
        $langId = 6;
        $formatId = 3;

        $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
            <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
            <soap12:Body>
                <GetProductsList xmlns="http://dedal.polcar.com.pl/Nemesis/WebServices">
                <Login>' . $soapUser . '</Login>
                <Password>' . $soapPassword . '</Password>
                <LanguageID>' . $langId . '</LanguageID>
                <FormatID>' . $formatId . '</FormatID>
                </GetProductsList>
            </soap12:Body>
            </soap12:Envelope>';

        $headers = [
            "Content-type: application/soap+xml",
            "Content-length: " . strlen($xml_post_string),
            "SOAPAction: http://dedal.polcar.com.pl/Nemesis/WebServices/GetProductsList",
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $soapUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        curl_close($ch);

        if (!$response) {
            throw new Exception('No response from SOAP service.');
        }
        $this->logMessage("getting the response and starting to parsing it.", $logFilePath);

        $resultArray = [];
        try {
            $xml = new SimpleXMLElement($response);
            $items = $xml->xpath("//ROOT/ITEM");

            foreach ($items as $item) {
                $resultArray[] = (int) $item['Number'];
            }
        } catch (Exception $e) {
            throw new Exception("Error parsing XML: " . $e->getMessage());
        }

        return $resultArray;
    }


    

    public function fetchProductsItems($products)
    {
        $logFilePath = __DIR__ . '/logs/operations-' . date('Y-m-d') . '.log';
        $this->logMessage("Starting fetchProductsItems operation.", $logFilePath);

        $soapUrl = "https://dedal.polcar.com/Sales/ProductsService.asmx";
        $soapUser = "eurlaf";
        $soapPassword = "ujdM676fj9sSrJt";
        $langId = 6;
        $branchId = 1;
        $maxItemsPerRequest = 50;

        $resultArray = [];

        // // Split products into chunks of 50
        // $productChunks = array_chunk($products, $maxItemsPerRequest);

        // foreach ($products as $index => $chunk) {
        $this->logMessage("Processing slice products.", $logFilePath);

        $partNumbersXml = '';
        foreach ($products as $product) {
            $partNumbersXml .= '<string>' . $product . '</string>';
        }

        // Build the SOAP request
        $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
                    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
                    <soap12:Body>
                        <GetStockLevelsAndPricesForItemsV4 xmlns="http://dedal.polcar.com/Integration/WebServices/Products">
                            <productRequest>
                                <BranchId>' . $branchId . '</BranchId>
                                <PartNumbers>' . $partNumbersXml . '</PartNumbers>
                            </productRequest>
                            <login>' . $soapUser . '</login>
                            <password>' . $soapPassword . '</password>
                            <languageId>' . $langId . '</languageId>
                        </GetStockLevelsAndPricesForItemsV4>
                    </soap12:Body>
                    </soap12:Envelope>';

        $headers = array(
            "Content-type: text/xml;charset=\"utf-8\"",
            "Accept: text/xml",
            "Content-length: " . strlen($xml_post_string),
        );

        // Initialize cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_URL, $soapUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $soapUser . ":" . $soapPassword);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);

        if (!$response) {
            throw new Exception('No response from SOAP service: ' . curl_error($ch));
        }
        curl_close($ch);

        // Parse the response
        try {
            $xml = new SimpleXMLElement($response);

            // Register namespaces for proper parsing
            $xml->registerXPathNamespace('soap', 'http://www.w3.org/2003/05/soap-envelope');
            $xml->registerXPathNamespace('ns', 'http://dedal.polcar.com/Integration/WebServices/Products');

            // Extract ProductV3 elements
            $products = $xml->xpath("//ns:ProductV3");
            foreach ($products as $product) {
                $resultArray[] = [
                    'PartNumber' => (string) $product->PartNumber,
                    'Quantity' => (int) $product->QuantityAvaliable,
                    'PartName' => (string) $product->PartName,
                    'Price' => (float) $product->Price,
                    'Currency' => (string) $product->Currency,
                    'Warehouse' => (string) $product->WarehouseNameOrDeliveryNumber,
                    'GtuCode' => (string) $product->GtuCode,
                    'SalesUnit' => (string) $product->SalesUnit,
                    'MeasureUnit' => (string) $product->MeasureUnit,
                ];
            }
        } catch (Exception $e) {
            dump("Error parsing XML: " . $e->getMessage());
            return false;
        }
        // }

        return $resultArray;
    }

    public function logMessage($message, $logFilePath = __DIR__ . '/logs/operations.log')
    {
        // Ensure the logs directory exists
        if (!is_dir(dirname($logFilePath))) {
            mkdir(dirname($logFilePath), 0777, true);
        }

        // Format the log message
        $timestamp = date('Y-m-d H:i:s');
        $formattedMessage = "[{$timestamp}] {$message}" . PHP_EOL;

        // Write the log message to the file
        file_put_contents($logFilePath, $formattedMessage, FILE_APPEND);
    }

    public function slugUrl($str)
    {

        // Convert string to lowercase
        $str = strtolower($str);

        // Replace the spaces with hyphens
        $str = str_replace(' ', '-', $str);

        // Remove the special characters
        $str = preg_replace('/[^a-z0-9\-]/', '', $str);

        // Remove the consecutive hyphens
        $str = preg_replace('/-+/', '-', $str);

        // Trim hyphens from the beginning
        // and ending of String
        $str = trim($str, '-');

        return $str;
    }

}
