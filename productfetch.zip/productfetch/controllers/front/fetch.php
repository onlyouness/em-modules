<?php

class ProductFetchFetchModuleFrontController extends ModuleFrontController
{

    public function initContent()
    {
        $soapLogin = Configuration::get('SOAPLOGIN');
        $soapPassword = Configuration::get('SOAPPASSWORD');
        $formatId = Configuration::get('SOAPFORMATID');
        $soapURLProducts = Configuration::get('SOAPURLPRODUCTS');
        $soapURLProductsAction = Configuration::get('SOAPACTIONPRODUCTS');
        $soapURLItems = Configuration::get('SOAPURLPRODUCTITEMS');
        $maxItemsPerRequest = Configuration::get('MAXPRODUCTS');


        $logFilePath = __DIR__ . '/logs/operations-' . date('Y-m-d') . '.log';

        // ! first i will get all the references that will help me with searching without open a connection with Db.
        $sql1 = new DbQuery();
        $sql1->select('l.reference');
        $sql1->from('product', 'l');
        $sql1->orderBy('l.reference ASC');
        $res = Db::getInstance()->executeS($sql1); 
        $references = array_column($res,'reference'); // this will flat the array
        


        $fetchedProducts = $this->fetchProductsAll($soapLogin,$soapPassword,$formatId,$soapURLProducts,$soapURLProductsAction);

        $limitedProducts = array_slice($fetchedProducts, 0, 10); // take two slices of products for testing

        $this->logMessage("Done getting all the products ", $logFilePath);

        $productDetails = $this->fetchProductsItems($limitedProducts,$soapLogin,$soapPassword,$soapURLItems,$maxItemsPerRequest);

        $insertedCount = 0;
        $totalProducts = count($productDetails);

        $this->logMessage("Starting inserting products into the DB.", $logFilePath);

        // Initialize the counter for successfully inserted products
        foreach ($productDetails as $index => $product) {
            $this->logMessage("Processing Product with index " . $index, $logFilePath);

            // Check if product already exists

            $exists = $this->binarySearch($references, $product['PartNumber']);
            if (!$exists) {
                try {
                    // Prepare product data for French (ID 1)
                    $productName = ['1' => $product['PartName']];
                    $description = ['1' => $product['Description']];
                    $link_rewrite = ['1' => $this->slugUrl($product['PartName'])];
                    $getCategoryID = 2; 

                    // Create a new Product object
                    $productObj = new Product();
                    $productObj->name = $productName;
                    $productObj->ean13 = ''; 
                    $productObj->reference = $product['PartNumber'];
                    $productObj->id_category_default = $getCategoryID;
                    $productObj->indexed = 1;
                    $productObj->description = $description;
                    $productObj->condition = 'new';
                    $productObj->redirect_type = '404';
                    $productObj->visibility = 'both';
                    $productObj->id_supplier = 1; 
                    $productObj->link_rewrite = $link_rewrite;
                    $productObj->quantity = (int) $product['Quantity'];
                    $productObj->price = (float) $product['Price'];
                    $productObj->active = 1;

                    // Add the product to the database
                    if ($productObj->add()) {
                        $productObj->addToCategories([$getCategoryID]); // assign the product to the Db
                        $this->logMessage("Product inserted successfully with ID " . $productObj->id, $logFilePath);
                        $insertedCount++;
                        array_push($references,$product['PartNumber']);
                        sort($references); //sort the new array

                    } else {
                        $this->logMessage("Error inserting product: " . $product['PartNumber'], $logFilePath);
                    }
                } catch (Exception $e) {
                    $this->logMessage("Error while processing product: " . $e->getMessage(), $logFilePath);
                }
            } else {
                $this->logMessage("Product already exists with reference " . $exists, $logFilePath);
            }
        }

        // After the loop, log the count of successfully inserted products
        $this->logMessage("Total products processed: " . $totalProducts, $logFilePath);
        $this->logMessage("Total products successfully inserted: " . $insertedCount, $logFilePath);


        $this->context->smarty->assign([
            'totalProducts' => $totalProducts,
            'insertedCount' => $insertedCount,
        ]);
        parent::initContent();
        $this->setTemplate('module:productfetch/views/templates/front/fetch.tpl');
    }

    public function fetchProductsAll($soapUser,$soapPassword,$formatId,$soapUrl,$soapURLProductsAction)
    {
        $logFilePath = __DIR__ . '/logs/operations-' . date('Y-m-d') . '.log';
        $this->logMessage("Starting fetchProductsAll operation.", $logFilePath);

        $langId = 6;

        $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
            <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
            <soap12:Body>
                <GetProductsList xmlns="http://dedal.polcar.com.pl/Nemesis/WebServices">
                <Login>' . $soapUser . '</Login>
                <Password>' . $soapPassword . '</Password>
                <LanguageID>' . $langId . '</LanguageID>
                <FormatID>' . $formatId . '</FormatID>
                </GetProductsList>
            </soap12:Body>
            </soap12:Envelope>';

        $headers = [
            "Content-type: application/soap+xml",
            "Content-length: " . strlen($xml_post_string),
            "SOAPAction: ".$soapURLProductsAction,
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $soapUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        curl_close($ch);

        if (!$response) {
            throw new Exception('No response from SOAP service.');
        }
        $this->logMessage("getting the response and starting to parsing it.", $logFilePath);

        $resultArray = [];
        try {
            $xml = new SimpleXMLElement($response);
            $items = $xml->xpath("//ROOT/ITEM");

            foreach ($items as $item) {
                $resultArray[] = (int) $item['Number'];
            }
        } catch (Exception $e) {
            throw new Exception("Error parsing XML: " . $e->getMessage());
        }

        return $resultArray;
    }

    public function fetchProductsItems($products,$soapUser,$soapPassword,$soapUrl,$maxItemsPerRequest)
    {
        $langId = 6;
        $branchId = 1;
        $resultArray = [];


        $logFilePath = __DIR__ . '/logs/operations-' . date('Y-m-d') . '.log';
        $this->logMessage("Starting fetchProductsItems operation.", $logFilePath);


        // // Split products into chunks of 50
        // $productChunks = array_chunk($products, $maxItemsPerRequest);

        // foreach ($products as $index => $chunk) {
        $this->logMessage("Processing slice products.", $logFilePath);

        $partNumbersXml = '';
        foreach ($products as $product) {
            $partNumbersXml .= '<string>' . $product . '</string>';
        }

        // Build the SOAP request
        $xml_post_string = '<?xml version="1.0" encoding="utf-8"?>
                    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
                    <soap12:Body>
                        <GetStockLevelsAndPricesForItemsV4 xmlns="http://dedal.polcar.com/Integration/WebServices/Products">
                            <productRequest>
                                <BranchId>' . $branchId . '</BranchId>
                                <PartNumbers>' . $partNumbersXml . '</PartNumbers>
                            </productRequest>
                            <login>' . $soapUser . '</login>
                            <password>' . $soapPassword . '</password>
                            <languageId>' . $langId . '</languageId>
                        </GetStockLevelsAndPricesForItemsV4>
                    </soap12:Body>
                    </soap12:Envelope>';

        $headers = array(
            "Content-type: text/xml;charset=\"utf-8\"",
            "Accept: text/xml",
            "Content-length: " . strlen($xml_post_string),
        );

        // Initialize cURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_URL, $soapUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $soapUser . ":" . $soapPassword);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);

        if (!$response) {
            throw new Exception('No response from SOAP service: ' . curl_error($ch));
        }
        curl_close($ch);

        // Parse the response
        try {
            $xml = new SimpleXMLElement($response);

            // Register namespaces for proper parsing
            $xml->registerXPathNamespace('soap', 'http://www.w3.org/2003/05/soap-envelope');
            $xml->registerXPathNamespace('ns', 'http://dedal.polcar.com/Integration/WebServices/Products');

            // Extract ProductV3 elements
            $products = $xml->xpath("//ns:ProductV3");
            foreach ($products as $product) {
                $resultArray[] = [
                    'PartNumber' => (string) $product->PartNumber,
                    'Quantity' => (int) $product->QuantityAvaliable,
                    'PartName' => (string) $product->PartName,
                    'Price' => (float) $product->Price,
                    'Currency' => (string) $product->Currency,
                    'Warehouse' => (string) $product->WarehouseNameOrDeliveryNumber,
                    'GtuCode' => (string) $product->GtuCode,
                    'SalesUnit' => (string) $product->SalesUnit,
                    'MeasureUnit' => (string) $product->MeasureUnit,
                ];
            }
        } catch (Exception $e) {
            dump("Error parsing XML: " . $e->getMessage());
            return false;
        }

        return $resultArray;
    }

    public function logMessage($message, $logFilePath = __DIR__ . '/logs/operations.log')
    {
        // Ensure the logs directory exists
        if (!is_dir(dirname($logFilePath))) {
            mkdir(dirname($logFilePath), 0777, true);
        }

        // Format the log message
        $timestamp = date('Y-m-d H:i:s');
        $formattedMessage = "[{$timestamp}] {$message}" . PHP_EOL;

        // Write the log message to the file
        file_put_contents($logFilePath, $formattedMessage, FILE_APPEND);
    }

    public function slugUrl($str)
    {
        // Convert string to lowercase
        $str = strtolower($str);

        // Replace the spaces with hyphens
        $str = str_replace(' ', '-', $str);

        // Remove the special characters
        $str = preg_replace('/[^a-z0-9\-]/', '', $str);

        // Remove the consecutive hyphens
        $str = preg_replace('/-+/', '-', $str);
        $str = trim($str, '-');

        return $str;
    }

    public function binarySearch($array, $element) {
        $start = 0;
        $end = count($array) - 1;
    
        while($start <= $end) {
            $mid = floor(($start + $end) / 2);
    
            if ( $element == $array[$mid] ) {
                return $array[$mid];
            } elseif ( $element > $array[$mid] ) {
                $start = $mid + 1;
            } else {
                $end = $mid -1;
            }
        }
        return false;
    }

}
