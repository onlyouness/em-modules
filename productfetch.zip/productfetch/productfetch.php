<?php

class ProductFetch extends Module
{

    public function __construct()

    {
        $this->name = 'productfetch';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Major media';
        parent::__construct();
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.7.8.0', 'max' => _PS_VERSION_];
        $this->bootstrap = true;
        $this->displayName = $this->l('Product Fetch', 'ProductFetch');
        $this->description = $this->l('Allows you to fetch products from an API');
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('displayHome') && $this->registerHook('moduleRoutes');
    }

    public function uninstall()
    {

        return parent::uninstall();
    }

    public function getContent()
    {
        $output = '';

        // This part is executed only when the form is submitted
        if (Tools::isSubmit('submit' . $this->name)) {
            
            $soapLogin = Tools::getValue('SOAPLOGIN');
            $soapPassword = Tools::getValue('SOAPPASSWORD');
            $soapFormatID = Tools::getValue('SOAPFORMATID');
            $soapURLProduct = Tools::getValue('SOAPURLPRODUCTS');
            $soapActionProducts = Tools::getValue('SOAPACTIONPRODUCTS');
            $soapURLItems = Tools::getValue('SOAPURLPRODUCTITEMS');
            $soapMaxProducts = Tools::getValue('MAXPRODUCTS');

            if (empty($soapLogin) && empty($soapPassword) ) {
                $output = $this->displayError($this->l('Please Provide a login and password'));
            } else {
                Configuration::updateValue('SOAPLOGIN', $soapLogin);
                Configuration::updateValue('SOAPPASSWORD', $soapPassword);
                Configuration::updateValue('SOAPFORMATID', $soapFormatID);
                Configuration::updateValue('SOAPURLPRODUCTS', $soapURLProduct);
                Configuration::updateValue('SOAPACTIONPRODUCTS', $soapActionProducts);
                Configuration::updateValue('SOAPURLPRODUCTITEMS', $soapURLItems);
                Configuration::updateValue('MAXPRODUCTS', $soapMaxProducts);
            
            }


            if (empty($output)) {
                $output = $this->displayConfirmation($this->l('Successfully Register Data'));
            }
        }

        return $output . $this->displayForm();
    }


    public function displayForm()
    {
    
        
        $form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Soap Configuration'),
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Soap Login'),
                        'name' => 'SOAPLOGIN',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Soap Password'),
                        'name' => 'SOAPPASSWORD',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Format ID'),
                        'name' => 'SOAPFORMATID',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Soap Url For All Products'),
                        'name' => 'SOAPURLPRODUCTS',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Soap Action For All Products'),
                        'name' => 'SOAPACTIONPRODUCTS',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Soap Url For Getting Product Items'),
                        'name' => 'SOAPURLPRODUCTITEMS',
                        'required' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('max Product Per Request '),
                        'name' => 'MAXPRODUCTS',
                        'required' => true,
                    ],
                

                ],
                'submit' => [
                    'title' => $this->l('Save'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->table = $this->table;
        $helper->name_controller = $this->name;

        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&' . http_build_query(['configure' => $this->name]);
        $helper->submit_action = 'submit' . $this->name;

        $helper->default_form_language = (int)Configuration::get('PS_LANG_DEFAULT');

    
        $helper->fields_value['SOAPLOGIN'] = Tools::getValue('SOAPLOGIN', Configuration::get('SOAPLOGIN'));
        $helper->fields_value['SOAPPASSWORD'] = Tools::getValue('SOAPPASSWORD', Configuration::get('SOAPPASSWORD'));
        $helper->fields_value['SOAPFORMATID'] = Tools::getValue('SOAPFORMATID', Configuration::get('SOAPFORMATID'));
        $helper->fields_value['SOAPURLPRODUCTS'] = Tools::getValue('SOAPURLPRODUCTS', Configuration::get('SOAPURLPRODUCTS'));
        $helper->fields_value['SOAPACTIONPRODUCTS'] = Tools::getValue('SOAPACTIONPRODUCTS', Configuration::get('SOAPACTIONPRODUCTS'));
        $helper->fields_value['SOAPURLPRODUCTITEMS'] = Tools::getValue('SOAPURLPRODUCTITEMS', Configuration::get('SOAPURLPRODUCTITEMS'));
        $helper->fields_value['MAXPRODUCTS'] = Tools::getValue('MAXPRODUCTS', Configuration::get('MAXPRODUCTS'));
        
        return $helper->generateForm([$form]);
    }




    public function hookDisplayHome(){
        
    }
    public function hookModuleRoutes($params)
    {
        return [
            'module-blogs' => [
                'controller' => 'fetch',
                'rule' => 'fetch',
                'keywords' => [
                
                ],
                'params' => [
                    'fc' => 'module',
                    'module' => 'productfetch',
                ],
            ],
        ];
    }
}
